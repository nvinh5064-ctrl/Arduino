public class Single {
	public static void main(String[] args)
    {
        String s = "1";
        System.out.println("Hello World!" + s);
    }
}