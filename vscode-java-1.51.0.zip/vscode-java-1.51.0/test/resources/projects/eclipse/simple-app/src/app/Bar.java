package app;

/**
 * Bar
 */
public class Bar {

	public void name() {
		Foo f = new Foo();
		f.call();
	}
}