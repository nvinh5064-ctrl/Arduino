package module1;

/**
 * Foo
 */
public class Foo {


}