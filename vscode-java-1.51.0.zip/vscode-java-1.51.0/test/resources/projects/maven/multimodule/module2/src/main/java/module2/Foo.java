package module2;

/**
 * Foo
 */
public class Foo {


}