import * as path from 'path';

export namespace constants {
    export const projectFsPath: string = path.join(__dirname, '..', '..', 'test-temp');
}